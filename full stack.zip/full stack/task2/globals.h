#ifndef GLOBALS_H
#define GLOBALS_H

#include <stdint.h>

extern uint8_t G_DataID;
extern int32_t G_DataValue;

typedef struct {
    uint8_t dataID;
    int32_t DataValue;
} Data_t;

#define QUEUE_LENGTH 5
#define QUEUE_ITEM_SIZE sizeof(Data_t)

#endif // GLOBALS_H
