#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "globals.h"
#include <stdio.h>

void ExampleTask1(void *pV) {
    Data_t dataToSend;
    while (1) {
        dataToSend.dataID = G_DataID;
        dataToSend.DataValue = G_DataValue;

        if (xQueueSend(Queue1, &dataToSend, portMAX_DELAY) != pdPASS) {
            printf("Failed to send to queue\n");
        }

        vTaskDelay(pdMS_TO_TICKS(500));
    }
}

void ExampleTask2(void *pV) {
    Data_t receivedData;
    UBaseType_t originalPriority = uxTaskPriorityGet(NULL);
    
    while (1) {
        if (xQueueReceive(Queue1, &receivedData, portMAX_DELAY) == pdPASS) {
            printf("Received data: dataID = %d, DataValue = %d\n", receivedData.dataID, receivedData.DataValue);

            switch (receivedData.dataID) {
                case 0:
                    vTaskDelete(NULL);
                    break;
                case 1:
                    if (receivedData.DataValue == 0) {
                        vTaskPrioritySet(NULL, originalPriority + 2);
                    } else if (receivedData.DataValue == 1) {
                        vTaskPrioritySet(NULL, originalPriority);
                    } else if (receivedData.DataValue == 2) {
                        vTaskDelete(NULL);
                    }
                    break;
                default:
                    break;
            }
        }
    }
}
