#ifndef QUEUE_H
#define QUEUE_H

#include "FreeRTOS.h"
#include "queue.h"

extern QueueHandle_t Queue1;

BaseType_t createQueue(void);

#endif // QUEUE_H
