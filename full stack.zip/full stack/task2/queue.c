#include "FreeRTOS.h"
#include "queue.h"
#include "globals.h"

QueueHandle_t Queue1;

BaseType_t createQueue(void) {
    Queue1 = xQueueCreate(QUEUE_LENGTH, QUEUE_ITEM_SIZE);
    return (Queue1 == NULL) ? pdFAIL : pdPASS;
}
