#include <stdio.h>
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "globals.h"
#include "tasks.h"
#include "queue.h"

int main(void) {
    // Create Queue1
    if (createQueue() != pdPASS) {
        printf("Failed to create queue\n");
        return 1;
    }

    // Create ExampleTask1
    if (xTaskCreate(ExampleTask1, "ExampleTask1", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY + 1, &TaskHandle_1) != pdPASS) {
        printf("Failed to create ExampleTask1\n");
        return 1;
    }

    // Create ExampleTask2
    if (xTaskCreate(ExampleTask2, "ExampleTask2", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY + 1, &TaskHandle_2) != pdPASS) {
        printf("Failed to create ExampleTask2\n");
        return 1;
    }

    // Start the scheduler
    vTaskStartScheduler();

    // Should never reach here
    for(;;);
}
