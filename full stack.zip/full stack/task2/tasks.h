#ifndef TASKS_H
#define TASKS_H

#include "FreeRTOS.h"
#include "task.h"

extern TaskHandle_t TaskHandle_1;
extern TaskHandle_t TaskHandle_2;

void ExampleTask1(void *pV);
void ExampleTask2(void *pV);

#endif // TASKS_H
