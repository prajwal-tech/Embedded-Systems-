#include <stdint.h>

#define NUM_INPUTS 8
#define CONSISTENT_COUNT 10


extern uint8_t g_ReadDIpinSts;
extern uint8_t g_AppDIpinSts;


static uint8_t consistentCount[NUM_INPUTS] = {0};


int ISR_DIsampling();

int ISR_DIsampling() {
   
    for (int i = 0; i < NUM_INPUTS; i++) {
        
        uint8_t mask = 1 << i;
        
        
        if ((g_ReadDIpinSts & mask) == (g_AppDIpinSts & mask)) {
            
            consistentCount[i]++;
        } else {
            
            consistentCount[i] = 0;
        }

        
        if (consistentCount[i] >= CONSISTENT_COUNT) {
            if (g_ReadDIpinSts & mask) {
                
                g_AppDIpinSts |= mask;
            } else {
                
                g_AppDIpinSts &= ~mask;
            }

            
            consistentCount[i] = 0;
        }
    }

    return 0;
}
